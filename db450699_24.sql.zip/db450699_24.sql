-- phpMyAdmin SQL Dump
-- version 2.11.11.3
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.3
-- Erstellungszeit: 12. Mai 2016 um 11:44
-- Server Version: 5.6.19
-- PHP-Version: 4.4.9

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Datenbank: `db450699_24`
--

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `guestbook`
--

CREATE TABLE `guestbook` (
  `guestbook_id` int(11) NOT NULL AUTO_INCREMENT,
  `guestbook_username` varchar(128) NOT NULL,
  `guestbook_message` text NOT NULL,
  `guestbook_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`guestbook_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Daten für Tabelle `guestbook`
--

INSERT INTO `guestbook` (`guestbook_id`, `guestbook_username`, `guestbook_message`, `guestbook_created`) VALUES
(11, 'Marten S', 'Die Anwendungs is fast ok.', '2016-05-10 20:12:43');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `homeworks`
--

CREATE TABLE `homeworks` (
  `homework_id` int(11) NOT NULL AUTO_INCREMENT,
  `homework_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `homework_description` text,
  PRIMARY KEY (`homework_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=23 ;

--
-- Daten für Tabelle `homeworks`
--

INSERT INTO `homeworks` (`homework_id`, `homework_date`, `homework_description`) VALUES
(8, '2016-04-14 00:10:24', 'Baut fÃ¼r das Registrierungsformular eine eigene Auswertung. Ãœbernehmt dafÃ¼r den HTML Quelltext aus der Loginseite auf eure eigene Seite (Nur registrierung) und prÃ¼ft ob alle Felder ausgefÃ¼llt sind. Alle Felder sind Pflichtfelder. Wenn der nutzer alle Felder ausgefÃ¼llt hat, also keine Fehler existieren, wird eine e-mail verschickt. Die Beste Registrierungsroutine wird in die Anwendung Ã¼bernommen. Viel SpaÃŸ :)\r\n\r\nDen Mailversand machen wir zusammen in der Vorlesung. Bitte konzentriert euch auf die Auswertung der Inputfelder.'),
(9, '2016-04-12 00:14:30', 'Expermientiert mit fopen, fclose, fwrite, fread, file_get_contents, und file(); alternativ mit readfile();\r\n\r\n<ul>\r\n        <li><a href="http://php.net/manual/en/function.fopen.php">fopen</a></li>\r\n        <li><a href="http://php.net/manual/de/function.fwrite.php">fwrite</a></li>\r\n        <li><a href="http://php.net/manual/en/function.fread.php">fread</a></li>\r\n        <li><a href="http://php.net/manual/en/function.fclose.php">fclose</a></li>\r\n        <li><a href="http://php.net/manual/en/function.file-get-contents.php">file_get_contents()</a></li>\r\n        <li><a href="http://php.net/manual/en/function.file.php">file()</a></li>\r\n        <li><a href="http://php.net/manual/en/function.readfile.php">readfile</a></li>\r\n        </ul>'),
(16, '2016-05-10 20:33:39', ''),
(17, '2016-05-10 20:40:30', 'asdasdasdasd\r\nasd\r\nasd\r\nasd');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `users`
--

CREATE TABLE `users` (
  `users_id` int(11) NOT NULL AUTO_INCREMENT,
  `users_username` varchar(128) NOT NULL,
  `users_password` varchar(32) NOT NULL,
  `users_email` varchar(128) NOT NULL,
  `users_status` int(1) NOT NULL,
  PRIMARY KEY (`users_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Daten für Tabelle `users`
--

INSERT INTO `users` (`users_id`, `users_username`, `users_password`, `users_email`, `users_status`) VALUES
(1, 'admin', '21232f297a57a5a743894a0e4a801fc3', 'admin@admin.de', 1),
(2, 'test', '7815696ecbf1c96e6894b779456d330e', 'test@test.de', 1),
(3, 'xy', '7815696ecbf1c96e6894b779456d330e', 'xy@test.de', 1),
(4, 'martens', '21232f297a57a5a743894a0e4a801fc3', 'm.stockenberg@sae.edu', 1);
